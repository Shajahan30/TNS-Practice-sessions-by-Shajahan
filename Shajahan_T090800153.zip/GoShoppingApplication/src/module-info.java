module GoShoppingApplication {
}