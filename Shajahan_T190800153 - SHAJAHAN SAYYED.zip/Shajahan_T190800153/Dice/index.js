// Variables to track game state
let currentPlayer = 1;
let scores = {1: 0, 2: 0, 3: 0};
let gameActive = true;

// Function to update the turn message
function updateTurnMessage() {
    document.getElementById("turnMessage").innerText = "Player " + currentPlayer + "'s turn to roll the dice";
}

// Function to roll the dice and update the image
function rollDice() {
    if (!gameActive) return; // Prevent rolling if the game is not active

    // Update the turn message
    updateTurnMessage();

    // Roll dice for the current player
    let randomNum = Math.floor(Math.random() * 6) + 1;
    let randomImageSource = "images/dice" + randomNum + ".png";
    let image = document.querySelector(".img" + currentPlayer);
    image.setAttribute("src", randomImageSource);

    // Update the score for the current player
    scores[currentPlayer] = randomNum;

    // Determine the next player or end the game
    if (currentPlayer < 3) {
        currentPlayer++;
    } else {
        determineWinner();
        gameActive = false; // End the game
    }

    // Update the turn message for the next player
    if (gameActive) {
        updateTurnMessage();
    }
}

// Function to determine the winner
function determineWinner() {
    let maxScore = Math.max(scores[1], scores[2], scores[3]);
    let winners = [];
    for (let player in scores) {
        if (scores[player] === maxScore) {
            winners.push("Player " + player);
        }
    }
    
    let result;
    if (winners.length === 1) {
        result = winners[0] + " Wins!";
    } else {
        result = "Draw: " + winners.join(" and ") + " win!";
    }
    document.querySelector("h1").innerHTML = result;
}

// Function to reset the game
function newGame() {
    currentPlayer = 1;
    scores = {1: 0, 2: 0, 3: 0};
    gameActive = true;
    document.querySelector("h1").innerHTML = "Refresh to Play Dice Game";

    // Reset dice images
    document.querySelector(".img1").setAttribute("src", "images/dice6.png");
    document.querySelector(".img2").setAttribute("src", "images/dice6.png");
    document.querySelector(".img3").setAttribute("src", "images/dice6.png");

    // Update the turn message
    updateTurnMessage();
}

// Add event listeners to buttons
document.getElementById("rollButton").addEventListener("click", rollDice);
document.getElementById("newGameButton").addEventListener("click", newGame);

// Optionally, start a new game when the page loads
newGame();
